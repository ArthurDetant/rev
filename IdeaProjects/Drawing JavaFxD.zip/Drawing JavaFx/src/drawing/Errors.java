package drawing;

public class Errors extends Exception {

    public Errors(){

    }

    public Errors(String s){
        super(s);
    }

}
